
#ifndef MOTOR_H_
#define MOTOR_H_

#include <string>


class Motor {
public:
	Motor();
	~Motor();
	void transition();
	void move(int velocity);
	void message(int velocity);

private:
	int velocity;
	std::string message_vel;
};


#endif // MOTOR_H_
