#include "display.h"

Display::Display(){
	return;
}

Display::~Display(){
	return;
}

void Display::display(std::string status, std::string message){
	
}

void Display::display(std::string status, int message){
	
}
