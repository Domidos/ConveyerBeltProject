
#include "systemManager.h"
#include "stateMachine.h"
#include "keyboard.h"
#include "myFunctions.h"
#include "MySystem.h"
extern "C" {
	#include "hwFunc.h"
}

StateMachine * myStateMachine;
MySystem * mySystem;
Keyboard * myKeyboard;
char key_board;
int n,m;

SystemManager :: SystemManager() {
	// Initialize table for all diagrams, event time in ms (POSIX)
	// The maximum size of the table is defined in stateTable.h:
	// MAXDIA = 9, MAXLINES = 66
	// Should these be exceeded, please correct!

	tab[0][0] = new TableEntry ("Leerlauf","Leerlauf","Timer0",1000,myAction00,myCondition00);
	tab[0][1] = new TableEntry ("Leerlauf","Modis","Timer0",1000,myAction01,myCondition01);
	tab[0][2] = new TableEntry ("Leerlauf","LokalerModi","Trigg_local",0,myAction02,myCondition02);
	tab[0][3] = new TableEntry ("Leerlauf","LokalerModi","Trigg_local",0,myAction03,myCondition03);
	tab[0][4] = new TableEntry ("Leerlauf","KettenModi","Trigg_chain",0,myAction04,myCondition04);

	tab[1][0] = new TableEntry ("StateC","StateD","Trigg1",0,myAction10,myCondition10);
	tab[1][1] = new TableEntry ("StateD","StateD","Timer1",4000,myAction11,myCondition11);
	tab[1][2] = new TableEntry ("StateD","StateE","Timer1",4000,myAction12,myCondition12);
	tab[1][3] = new TableEntry ("StateE","StateC","Timer1",3000,myAction13,myCondition13);

	tab[2][0] = new TableEntry ("StateK","StateK","Timer2",200,myAction20,myCondition20);

	// Initialize timer names for all diagrams
	// Timer names are always Timer followed by the diagram number
	timerNames[0] = "Timer0";
	timerNames[1] = "Timer1";
	timerNames[2] = "Timer2";

	// Initialize line numbers for all diagrams
	lines[0] = 5;
	lines[1] = 4;
	lines[2] = 1;

	// Initialize first state for all diagrams
	actualState[0] = "Leerlauf";
	actualState[1] = "StateC";
	actualState[2] = "StateK";
	
	// Set the actual number of diagrams
	diagrams = 3;
	

	// Create instance of state machine
	myStateMachine = new StateMachine;
	
	mySystem = new MySystem;
	
	// Create instance of my Keyboard
		myKeyboard = new Keyboard;

	// Start timer for each diagram which needs one in the first state!
	// In my case these are diagram 0 and 2
	myStateMachine->diaTimerTable[0]->startTimer(tab[0][0]->eventTime);
	myStateMachine->diaTimerTable[2]->startTimer(tab[2][0]->eventTime);

	// Initial actions can be done here, if needed!
	n = 0;
	m = 0;

	return;
}

SystemManager :: ~SystemManager() {
	return;
}

void SystemManager :: action00(){
	printf("Leerlauf -> Transition00 -> Leerlauf\n\r"); 
	printf("Key: %c\n",key_board);
	mySystem->idle();
	return;
}

void SystemManager :: action01(){
	if(key_board == '1'){
	printf("Leerlauf -> Transition01 -> LokalerModi\n\r");
	}
	else if (key_board == '2'){
		printf("Leerlauf -> Transition02 -> KettenModi\n\r");
	}

	return;
}


void SystemManager :: action02(){
	printf("Leerlauf -> Transition01 -> LokalerModi\n\r");
	if(key_board == 'F'){
		writeAnalog(0,4095);
		motorOn();}
	return;
}

void SystemManager :: action03(){
	printf(" StateB -> Transition02 -> StateA\n\r"); 
	//mySystem->listen_keyboard();
	n = 0;
	return;
}

void SystemManager :: action04(){
	printf(" StateB -> Transition02 -> StateA\n\r"); 
	//mySystem->listen_keyboard();
	n = 0;
	return;
}

void SystemManager :: action10(){
	printf(" StateC -> Transition10 -> StateD\n\r"); 
	//mySystem->listen_keyboard();
	m = 0;
	return;
}

void SystemManager ::action11(){
	printf(" StateD -> Transition11 -> StateD\n\r"); 
	//mySystem->listen_keyboard();
	m++;
	return;
}

void SystemManager :: action12(){
	printf(" StateD -> Transition12 -> StateE\n\r"); 
	//mySystem->listen_keyboard();
	return;
}

void SystemManager :: action13(){
	printf(" StateE -> Transition13 -> StateC\n\r"); 
	myStateMachine->sendEvent("Trigg0");
	return;
}

void SystemManager :: action20(){
	//myKeyboard->getPressedKey();
	key_board = mySystem->listen_keyboard();
	printf("NEUER KEY:         %c\n", key_board);
	return;
}

bool SystemManager :: conditionTrue(){
	return TRUE;
}

bool SystemManager :: condition00(){
	if (key_board != (('1')||('2'))) {
		printf("TRUE \n");
		return TRUE;}
	
	else return FALSE;
}

bool SystemManager :: condition01(){
	if(key_board == ('1'||'2')){printf("BLAAAAAAA");return TRUE;}
	else return FALSE;
}

bool SystemManager :: condition02(){
if (key_board == '1') {return TRUE;
	printf("KEYY Condition 1");}
else return FALSE;
}

bool SystemManager :: condition03(){
	if (m < 4) return TRUE;
	else return FALSE;
}

bool SystemManager :: condition04(){
	if (m < 4) return TRUE;
	else return FALSE;
}

bool SystemManager :: condition11(){
	if (m < 4) return TRUE;
	else return FALSE;
}

bool SystemManager :: condition12(){
	if (m >= 4) return TRUE;
	else return FALSE;
}
