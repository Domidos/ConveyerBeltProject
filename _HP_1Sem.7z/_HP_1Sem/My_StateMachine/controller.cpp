
#include "controller.h"

Controller::Controller(){
	return;
}

Controller::~Controller(){
	return;
}

void Controller::control(){
	
}

void Controller::message(int velocity){
	
}

