#include "tcp_client.h"

TCP_Client::TCP_Client(){
	return;
}

TCP_Client::~TCP_Client(){
	return;
}

void TCP_Client::listen(){
	
}

void TCP_Client::wait(){
	
}

void TCP_Client::ready() {
	
}

void TCP_Client::request(){
	
}

void TCP_Client::release(){
	
}
