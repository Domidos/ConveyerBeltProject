
#include "motor.h"

Motor::Motor(){
	return;
}

Motor::~Motor(){
	return;
}

void Motor::transition(){
	
}

void Motor::move(int velocity){
	
}

void Motor::message(int velocity){
	
}
