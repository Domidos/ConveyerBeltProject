
#ifndef MYFUNCTIONS_H_
#define MYFUNCTIONS_H_

void myAction00();
void myAction01();
void myAction02();
void myAction03();
void myAction04();
void myAction05();

void myAction10();
void myAction11();
void myAction12();
void myAction13();

void myAction20();

void myAction30();

bool myCondition00();
bool myCondition01();
bool myCondition02();
bool myCondition03();
bool myCondition04();
bool myCondition05();

bool myCondition10();
bool myCondition11();
bool myCondition12();
bool myCondition13();

bool myCondition20();

#endif // MYFUNCTIONS_H_
