#include <stdio.h>
#include <sysLib.h>
#include <stdLib.h>
#include "keyboard.h"

extern "C" {
	#include "hwFunc.h"
}

char key_buffer;
char key;

Keyboard :: Keyboard() {
	printf("Keyboard Konstruktor!\n\r");	
	return;
}

Keyboard :: ~Keyboard() {
	pressedKey = 0;
	return;
}

char Keyboard::getPressedKey( )
{
	key= getKey();
	if(key != '\0')
		{
		 key_buffer = key;
		 printf("PresseKey: %c\n", key);
		}
	key = key_buffer;
	pressedKey = key;

	return pressedKey;
}
