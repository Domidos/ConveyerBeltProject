
#ifndef TCP_SERVER_H_
#define TCP_SERVER_H_

#include <string>

class TCP_Server {
public:
	TCP_Server();
	~TCP_Server();
	void listen();
	void ready();
	void wait();
	void request();
	void release();
	

private:
	bool flag_wait;
	bool flag_ready;
	bool flag_release;
	bool flag_request;
};


#endif // TCP_SERVER_H_
