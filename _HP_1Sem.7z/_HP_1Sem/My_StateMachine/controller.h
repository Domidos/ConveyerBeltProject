
#ifndef CONTROLLER_H_
#define CONTROLLER_H_

#include <string>

class Controller {
public:
	Controller();
	~Controller();
	void control();
	void message(int velocity);

private:
	int velocity;
	std::string message_contr;
};

#endif // CONTROLLER_H_
