#include <stdio.h>
#include <sysLib.h>
#include <stdLib.h>
#include "MySystem.h"
#include "keyboard.h"
#include "systemManager.h"

extern "C" {
	#include "hwFunc.h"
}
Keyboard * myKeyboard;

MySystem::MySystem() {
	printf("MySystem Konstruktor!\n\r");	
	return;
}

MySystem :: ~MySystem() {
	key = 0;
	return;
}

std::string MySystem::listen_signal( )
{
	signal = "";


	return signal;
}

void MySystem::message(std::string status)
{
	
}

char MySystem::listen_keyboard()
{
	
	key = myKeyboard->getPressedKey();
	return key;
}

void MySystem::idle()
{
	
}

void MySystem::startbutton()
{
	
}

void MySystem::start(std::string mode, std::string rotation)
{
	
}

void MySystem::set_velocity(int velocity)
{
	
}

void MySystem::set_rotation(std::string rotation)
{
	
}
