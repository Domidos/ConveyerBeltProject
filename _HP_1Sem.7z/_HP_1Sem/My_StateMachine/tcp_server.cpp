#include "tcp_server.h"

TCP_Server::TCP_Server(){
	
}

TCP_Server::~TCP_Server(){
	
}

void TCP_Server::listen(){
	
}

void TCP_Server::ready(){
	
}

void TCP_Server::wait(){
	
}

void TCP_Server::request(){
	
}

void TCP_Server::release(){
	
}


