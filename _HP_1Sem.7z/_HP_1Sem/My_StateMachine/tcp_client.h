
#ifndef TCP_CLIENT_H_
#define TCP_CLIENT_H_

#include <string>

class TCP_Client {
public:
	TCP_Client();
	~TCP_Client();
	void listen();
	void ready();
	void wait();
	void request();
	void release();
	

private:
	bool flag_wait;
	bool flag_ready;
	bool flag_release;
};


#endif // TCP_CLIENT_H_
