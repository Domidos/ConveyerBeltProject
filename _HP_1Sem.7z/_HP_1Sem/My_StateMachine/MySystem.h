
#ifndef MYSYSTEM_H_
#define MYSYSTEM_H_

#include <string>

class MySystem
{
	
public:
	MySystem();
	~MySystem();
	std::string listen_signal();
	void message(std::string status);
	char listen_keyboard();
	void set_velocity(int velocity);
	void set_rotation(std::string rotation);
	void idle();
	void startbutton();
	void start(std::string mode, std::string rotation);
private:
	std::string status;
	std::string mode;
	char key;
	std:: string signal;
	int velocity;
	std::string rotation;
	bool start_button;

};

#endif // MYSYSTEM_H_
