
#ifndef DISPLAY_H_
#define DISPLAY_H_

#include <string>

class Display {
public:
	Display();
	~Display();
	void display(std::string status, std::string message);
	void display(std::string status, int velocity);

private:
	std::string message_txt;
	int message_vel;
	std::string status;
};


#endif // DISPLAY_H_
