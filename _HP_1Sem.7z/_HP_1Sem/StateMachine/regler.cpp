//Defines For Regler

 //Includes for Regler
#include <stdio.h>
#include <sysLib.h>
#include <stdLib.h>
#include <taskLib.h>

#include "systemManager.h"
#include "stateMachine.h"

#include "myFunctions.h"
#include "regler.h"

#define priority 220

extern "C" 
{
	#include "hardware/hwFunc.h"

	//Includes for Regler
	int Subsystem_main(int prio);


}


//StateMachine * myStateMachine;

//Variablen


//Funktionen

void Regler :: reglerInit(){ 

	int reglerID;
	reglerID = taskSpawn ("Subsystem_main", priority, 0,0x10000,(FUNCPTR) Subsystem_main,100,0,0,0,0,0,0,0,0,0);

	return;
}

Regler :: Regler() {
	
	printf("Regler Konstruktor!\n\r");	
	
	/*
	analogInputs = semBCreate (SEM_Q_PRIORITY, SEM_FULL);
	writeDisplay = semBCreate (SEM_Q_PRIORITY, SEM_FULL);
	*/
	
	return;
}

Regler :: ~Regler() {
	return;
}


			


