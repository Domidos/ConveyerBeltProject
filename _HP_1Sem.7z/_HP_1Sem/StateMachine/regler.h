#ifndef REGLER_H_
#define REGLER_H_

class Regler
{
	
public:
	Regler();
	~Regler();
	void reglerInit();
	
private:
	char output[64];
};


// functions
//int Subsystem_main(int priority);



#endif // REGLER_H_
