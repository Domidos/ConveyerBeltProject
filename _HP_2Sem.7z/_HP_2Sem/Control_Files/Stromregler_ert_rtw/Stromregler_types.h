/*
 * File: Stromregler_types.h
 *
 * Code generated for Simulink model 'Stromregler'.
 *
 * Model version                  : 1.16
 * Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
 * C/C++ source code generated on : Thu May 19 14:35:39 2016
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Stromregler_types_h_
#define RTW_HEADER_Stromregler_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_Stromregler_T RT_MODEL_Stromregler_T;

#endif                                 /* RTW_HEADER_Stromregler_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
