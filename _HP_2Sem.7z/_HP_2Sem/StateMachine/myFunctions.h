
#ifndef MYFUNCTIONS_H_
#define MYFUNCTIONS_H_

void myAction00();
void myAction01();
void myAction02();
void myAction03();

void myAction10();
void myAction11();
void myAction12();
void myAction13();
void myAction14();

void myAction20();
void myAction21();
void myAction22();
void myAction23();
void myAction24();

void myAction30();

bool myCondition00();
bool myCondition01();
bool myCondition02();
bool myCondition03();
bool myCondition04();

bool myCondition10();
bool myCondition11();
bool myCondition12();
bool myCondition13();
bool myCondition14();

bool myCondition20();
bool myCondition21();
bool myCondition22();
bool myCondition23();
bool myCondition24();

bool myCondition30();

#endif // MYFUNCTIONS_H_
