
#include <stdio.h>
#include "systemManager.h"
#include "stateMachine.h"
#include "keyboard.h"
#include "myFunctions.h"



extern "C" {
#include "hwFunc.h"
}

int n, m, value;
bool direction;

StateMachine * myStateMachine;
Keyboard * myKeyboard;
TCP_Server * myTPCServer;
Telnet_Server * myTelnetServer;
TCP_Client * myTCPClient;

SystemManager :: SystemManager() {
	// Initialize table for all diagrams, event time in ms (POSIX)
	// The maximum size of the table is defined in stateTable.h:
	// MAXDIA = 9, MAXLINES = 66
	// Should these be exceeded, please correct!

	tab[0][0] = new TableEntry ("idleState","chainIdle","setCommandChain",0,myAction00,myCondition01); //condition02 ist immer true!
	tab[0][1] = new TableEntry ("idleState","localIdle","setCommandLocal",0,myAction01,myCondition02);
	tab[0][2] = new TableEntry ("chainIdle","localIdle","localMode",0,myAction02,myCondition03);
	tab[0][3] = new TableEntry ("localIdle","chainIdle","chainIdle",0,myAction03,myCondition04);

	tab[1][0] = new TableEntry ("localIdle","localIdle","setSpeed++",0,myAction10,myCondition10); //Geschwindigkeit erh�hen
	tab[1][1] = new TableEntry ("localIdle","localIdle","setSpeed--",0,myAction11,myCondition11); //Geschwindigkeit herabsetzen
	tab[1][2] = new TableEntry ("localIdle","localIdle","directionRight",0,myAction12,myCondition12); //Richtung rechts w�hlen
	tab[1][3] = new TableEntry ("localIdle","localIdle","directionLeft",0,myAction13,myCondition13); //Richtung links w�hlen
	tab[1][4] = new TableEntry ("localIdle","move","start",0,myAction14,myCondition14);	// Profil abfahren

	// getStatus(Request) und send(Wait) muss noch in jede Action implementiert werden!
	// subcase in Programmcode nicht m�glich.
	tab[2][0] = new TableEntry ("chainIdle","slowMovement","getStatus",0,myAction20,myCondition20); //start in Funktion getStatus implementieren
	tab[2][1] = new TableEntry ("slowMovement","movingProfile","Timer0",1000,myAction21,myCondition21); //send und movingProfile in stop() implementieren
	tab[2][2] = new TableEntry ("movingProfile","packageDelivery","Timer0",8000,myAction22,myCondition22); //stop in Funktion stop implementieren
	tab[2][3] = new TableEntry ("packageDelivery","slowMovement","start",0,myAction23,myCondition23);
	tab[2][4] = new TableEntry ("slowMovement","chainIdle","getStatus",0,myAction24,myCondition24); //stop und busy=false noch implementieren
	
	tab[3][0] = new TableEntry ("StateK","StateK","Timer1",100,myAction30,myCondition30);

	// Initialize timer names for all diagrams
	// Timer names are always Timer followed by the diagram number
	timerNames[2] = "Timer0";
	timerNames[3] = "Timer1";
	
	

	// Initialize line numbers for all diagrams
	lines[0] = 4;
	lines[1] = 5;
	lines[2] = 5;
	lines[3] = 1;

	// Initialize first state for all diagrams
	actualState[0] = "idleState";
	actualState[1] = "localIdle";
	actualState[2] = "chainIdle";
	actualState[3] = "StateK";
	
	// Set the actual number of diagrams
	diagrams = 4;
	
	// Create instance of my Keyboard
	myKeyboard = new Keyboard;

	// Create instance of state machine
	myStateMachine = new StateMachine;
	
	// Create instance of TCP Server
	myTCPServer = new TCP_Server;
	myTCPServer->init();
	
	// Create instance of Telnet Server
	myTelnetServer = new Telnet_Server;
	myTelnetServer->init();
	
	// Create instance of TCP Client
	myTCPClient = new TCP_Client;
	myTCPClient->init();

	// Start timer for each diagram which needs one in the first state!
	// In my case these are diagram 0 and 2
//	myStateMachine->diaTimerTable[0]->startTimer(tab[0][0]->eventTime);
//	myStateMachine->diaTimerTable[2]->startTimer(tab[2][1]->eventTime);
//	myStateMachine->diaTimerTable[2]->startTimer(tab[2][2]->eventTime);
	myStateMachine->diaTimerTable[3]->startTimer(tab[3][0]->eventTime);

	// Initial actions can be done here, if needed!
	n = 0;
//	m = 0;
	int initialSpeed=200;
	BOOLEAN direction = 1;
	
	//Initialoutput**********************************************************************************
	
	sprintf(textOutput,"Speed is:  %i 							   ", initialSpeed);
	writeToDisplay (0, 0, textOutput );
	
	sprintf(textOutput,"Direction is: rechts oder links -- noch �berpr�fen  ");
	writeToDisplay (1, 0, textOutput );
	
	sprintf(textOutput,"Message received: non           ");
	writeToDisplay (2, 0, textOutput );
	
	sprintf(textOutput,"Message sent: non           ");
	writeToDisplay (3, 0, textOutput );
	
	sprintf(textOutput,"actual state: idleState           ");
	writeToDisplay (3, 0, textOutput );

	//************************************************************************************************
	
	return;
}

SystemManager :: ~SystemManager() {
	return;
}

// Funktionen f�r erstes Use-Case-Diagramm

//action00 -> Methode von idle in chain oder local mode
void SystemManager :: action00() {
	
	char tempKey = myKeyboard->getPressedKey();
	
	
	switch (tempKey)
	{
	case 'A':
		
		printf(" idle State -> Transition00 -> chain Mode\n\r");
		myStateMachine->sendEvent("setCommandChain");
		n=n+2;
		break;
	case 'B':
		printf(" idle State -> Transition01 -> local Mode");
		myStateMachine->sendEvent("setCommandLocal");
		n++;
		break;
		}		
	return;
	
}

void SystemManager :: action01() {
	
}

// Methode um von chainMode in localMode zu springen
void SystemManager :: action02(){
	char tempKey;
		tempKey = getKey();
	printf(" chain Mode -> Transition02 -> local Mode\n\r"); 
	myStateMachine->sendEvent("localIdle");
	n--;
	return;
}

// Mehode um von localMode in chainMode zu springen
void SystemManager :: action03(){
	char tempKey;
			tempKey = getKey();
		printf(" local Mode -> Transition03 -> chain Mode\n\r"); 
		myStateMachine->sendEvent("chainIdle");
		n++;
		return;
}


// Funktionen f�r zweites Use-Case-Diagramm (local Mode)

// Methode um Geschwindigkeit um 1(100rpm) zu erh�hen
void SystemManager ::action10(){
	char tempKey;
			tempKey = getKey();
		
		int value = readAnalog(0,2);
		if (tempKey == '1') {
		if (direction == true){
			
			myStateMachine->sendEvent("setSpeed++");
			printf("raise speed by 100 rpm\n\r"); 
			value = value + 94;
			writeAnalog(0, value);
		}
			else if (direction == false){
			myStateMachine->sendEvent("setSpeed++");
			printf("raise speed by 100 rpm\n\r"); 
			value = value - 94;
			writeAnalog(0, value);
			}
		}
		printf("current value of speed is: %d", value);
		return;
}

// Methode um Geschwindikeit um 1(100rpm) zu verkleinern
void SystemManager :: action11(){
	char tempKey;
				tempKey = getKey();
			
		int value = readAnalog(0,2);
		if (tempKey == '2') {
			if (direction == true){
							
			myStateMachine->sendEvent("setSpeed--");
			writeToDisplay(4,0, "raise speed by 100 rpm\n\r"); 
			value = value - 94;
		}
			else if (direction == false){
			myStateMachine->sendEvent("setSpeed--");
			writeToDisplay(4,0, "raise speed by 100 rpm\n\r"); 
			value = value + 94;
			}
		}
		writeToDisplay(5,0, "current value of speed is: ");
		return;
}

// Methode um Richtung nach rechts einzustellen
void SystemManager :: action12(){
	char tempKey = myKeyboard->getPressedKey();
			tempKey = getKey();
			if (tempKey == '3'){
				direction = true;
				writeToDisplay (2, 0, "direction = true (rechts)");
			}
}

// Methode um Richtung nach links einzustellen
void SystemManager :: action13(){
	char tempKey = myKeyboard->getPressedKey();
			tempKey = getKey();
			if (tempKey == '4'){
				direction = false;
				writeToDisplay (2, 0, "direction = false (links)");
			}
}

// Methode um Profil in local Mode abzufahren
void SystemManager :: action14(){
	char tempKey = myKeyboard->getPressedKey();
			tempKey = getKey();
			if (tempKey == '5'){
				writeAnalog(0, value);
			}
}


// Funktionen f�r drittes Use-Case-Diagramm
void SystemManager :: action20(){
	myStateMachine->sendEvent("getStatus");
	myKeyboard->getPressedKey();
	return;
}

void SystemManager :: action21(){
	myStateMachine->sendEvent("send(Release)");
	myKeyboard->getPressedKey();
	return;
}

void SystemManager :: action22(){
	myStateMachine->sendEvent("send(Request)");
	myKeyboard->getPressedKey();
	return;
}


void SystemManager :: action23(){
	myStateMachine->sendEvent("start");
	myKeyboard->getPressedKey();
	return;
}

void SystemManager :: action24(){
	myStateMachine->sendEvent("getStatus");
	myKeyboard->getPressedKey();
	return;
}

void SystemManager :: action30(){
	char key = myKeyboard->getPressedKey();
	
	printf (".");
	if (key == 'A') {
		
		//Test*****************************************************************************************
		writeAnalog (0, 600); 												//Motor konfigurieren
		motorOn();															//Motor starten
		writeToDisplay (0, 0, "Start wurde gedrueckt (Stop mit Taste B)");
		writeToDisplay (20, 0, "                                                              ");
		printf ("Taste A gedr�ckt\n");
		//*********************************************************************************************
		
		myStateMachine->sendEvent("");
	
	}
	else if (key == 'B'){
		
		//Test*****************************************************************************************
		motorOff();	//Motor stoppen
		printf ("Taste B gedr�ckt\n");
		writeToDisplay (0, 0, "                                                               ");
		writeToDisplay (20, 0, "Stop wurde gedrueckt (Start mit Taste A)");
		//*********************************************************************************************
		
	}
	return;
}


bool SystemManager :: conditionTrue(){
	return TRUE;
}

bool SystemManager :: condition00(){
	if (n < 5) {
		return TRUE;
	}
	else return FALSE;
}

bool SystemManager :: condition01(){
	if (n >= 5) return TRUE;
	else return FALSE;
}

bool SystemManager :: condition11(){
	if (m < 4) return TRUE;
	else return FALSE;
}

bool SystemManager :: condition12(){
	if (m >= 4) return TRUE;
	else return FALSE;
}
