
STATUS sendClk (int debug);

STATUS procReq (int debug);

STATUS syncClk (int debug);
